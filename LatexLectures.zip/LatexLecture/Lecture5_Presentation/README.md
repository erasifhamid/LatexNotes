# LaTeX-For-Everyone-and-Everything
LaTeX For Everyone and Everything, published by Packt
